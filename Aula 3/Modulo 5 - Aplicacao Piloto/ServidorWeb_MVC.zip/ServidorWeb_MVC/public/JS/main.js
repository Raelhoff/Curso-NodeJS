angular.module('contatooh',['ngRoute', 'ngResource'])
  .config(function($routeProvider) {
   
    $routeProvider.when('/dispositivos', {
      templateUrl: 'partials/Tabela.html',
      controller: 'contato'
    });

    //  $routeProvider.otherwise({redirectTo:'/dispositivos'});
});